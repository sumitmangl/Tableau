# Tableau Icons

A collection of open-source icons processed for use in Tableau Dashboards.
